import { oklch } from '../color/oklch.js';
import type { Palette, PaletteScale, PaletteStep } from './types.js';

/** One color's OKLCH coordinates: lightness 0–1, chroma, hue in degrees. */
export type Oklch = readonly [l: number, c: number, h: number];
/** A scale's twelve steps in OKLCH, step 1 first. */
export type OklchScale = readonly Oklch[];

// Each built-in scale is kept as OKLCH coordinates, which generateScale's
// curves are read from, and resolved once to the sRGB hex the theme carries.
// Every coordinate sits inside sRGB (palette.test.ts), which is why a few carry
// an extra decimal.
function toScale(source: OklchScale): PaletteScale {
  const scale = {} as Record<PaletteStep, string>;
  source.forEach(([l, c, h], i) => {
    scale[(i + 1) as PaletteStep] = oklch(l, c, h);
  });
  return scale;
}

/** The light scheme's surface, and the ink on its solid fills. */
export const white: string = /* @__PURE__ */ oklch(1, 0, 0);

/** Radix-Colors-inspired 12-step gray scale (light-friendly). */
export const grayScaleOklch: OklchScale = [
  [0.991, 0, 0],
  [0.982, 0, 0],
  [0.955, 0, 0],
  [0.931, 0, 0],
  [0.907, 0, 0],
  [0.885, 0, 0],
  [0.851, 0, 0],
  [0.792, 0, 0],
  [0.643, 0, 0],
  [0.61, 0, 0],
  [0.503, 0, 0],
  [0.244, 0, 0],
];
export const grayScale: PaletteScale = /* @__PURE__ */ toScale(grayScaleOklch);

export const blueScaleOklch: OklchScale = [
  [0.993, 0.003, 248],
  [0.982, 0.009, 243],
  [0.96, 0.02, 239],
  [0.938, 0.0349, 235],
  [0.905, 0.051, 240],
  [0.863, 0.068, 243],
  [0.81, 0.089, 243],
  [0.734, 0.121, 243],
  [0.649, 0.193, 251.8],
  [0.622, 0.183, 251.7],
  [0.556, 0.1622, 252.2],
  [0.324, 0.096, 258.8],
];
export const blueScale: PaletteScale = /* @__PURE__ */ toScale(blueScaleOklch);

export const redScaleOklch: OklchScale = [
  [0.993, 0.003, 17],
  [0.982, 0.0087, 17],
  [0.955, 0.021, 14],
  [0.922, 0.0399, 16],
  [0.892, 0.056, 17],
  [0.857, 0.074, 18],
  [0.807, 0.089, 18],
  [0.744, 0.113, 19],
  [0.626, 0.193, 23],
  [0.599, 0.195, 24],
  [0.557, 0.197, 25.2],
  [0.339, 0.109, 17],
];
export const redScale: PaletteScale = /* @__PURE__ */ toScale(redScaleOklch);

export const greenScaleOklch: OklchScale = [
  [0.994, 0.004, 157],
  [0.981, 0.01, 155],
  [0.958, 0.022, 156],
  [0.934, 0.037, 156],
  [0.9, 0.052, 156],
  [0.856, 0.064, 158],
  [0.798, 0.083, 159],
  [0.716, 0.113, 160.3],
  [0.641, 0.133, 157.7],
  [0.611, 0.1266, 158.2],
  [0.543, 0.1116, 159.5],
  [0.322, 0.048, 164.5],
];
export const greenScale: PaletteScale = /* @__PURE__ */ toScale(greenScaleOklch);

export const defaultPalette: Palette = {
  gray: grayScale,
  blue: blueScale,
  red: redScale,
  green: greenScale,
};

/** Dark-scheme palette scales (inverted roles). */
export const grayScaleDarkOklch: OklchScale = [
  [0.178, 0, 0],
  [0.213, 0, 0],
  [0.252, 0, 0],
  [0.285, 0, 0],
  [0.313, 0, 0],
  [0.348, 0, 0],
  [0.402, 0, 0],
  [0.489, 0, 0],
  [0.538, 0, 0],
  [0.583, 0, 0],
  [0.77, 0, 0],
  [0.949, 0, 0],
];
export const grayScaleDark: PaletteScale = /* @__PURE__ */ toScale(grayScaleDarkOklch);

export const blueScaleDarkOklch: OklchScale = [
  [0.194, 0.025, 256],
  [0.213, 0.03, 261],
  [0.274, 0.066, 254],
  [0.32, 0.097, 252.5],
  [0.367, 0.1058, 250.7],
  [0.416, 0.113, 252],
  [0.474, 0.122, 253],
  [0.541, 0.14, 253.2],
  [0.649, 0.193, 251.8],
  [0.688, 0.169, 251.4],
  [0.764, 0.1258, 249.5],
  [0.907, 0.051, 238],
];
export const blueScaleDark: PaletteScale = /* @__PURE__ */ toScale(blueScaleDarkOklch);

export const redScaleDarkOklch: OklchScale = [
  [0.188, 0.013, 18],
  [0.205, 0.022, 14],
  [0.251, 0.065, 13],
  [0.289, 0.095, 14],
  [0.332, 0.107, 15.5],
  [0.381, 0.111, 17],
  [0.45, 0.121, 19],
  [0.544, 0.146, 22],
  [0.626, 0.193, 23],
  [0.663, 0.177, 23],
  [0.78, 0.128, 22],
  [0.902, 0.053, 6],
];
export const redScaleDark: PaletteScale = /* @__PURE__ */ toScale(redScaleDarkOklch);

export const greenScaleDarkOklch: OklchScale = [
  [0.187, 0.012, 167],
  [0.212, 0.015, 166],
  [0.272, 0.04, 162],
  [0.317, 0.057, 162],
  [0.365, 0.066, 161],
  [0.412, 0.072, 161],
  [0.467, 0.082, 160.2],
  [0.528, 0.096, 159.4],
  [0.641, 0.133, 157.7],
  [0.675, 0.141, 157.7],
  [0.779, 0.1655, 157.3],
  [0.905, 0.083, 158],
];
export const greenScaleDark: PaletteScale = /* @__PURE__ */ toScale(greenScaleDarkOklch);

export const defaultPaletteDark: Palette = {
  gray: grayScaleDark,
  blue: blueScaleDark,
  red: redScaleDark,
  green: greenScaleDark,
};
