/**
 * Emit React Native accessibility object props together with react-native-web
 * ARIA aliases. RNW 0.21 forwards flattened `accessibilityValueMin/Max/Now/Text`
 * and DOM ARIA attributes, not the RN object shapes — without aliases, Checkbox
 * `aria-checked` and Progress `aria-valuenow` would silently vanish in
 * Storybook / jsdom tests.
 *
 * Also the react-native-web DOM shapes (keys, focus) its components read,
 * typed here once since silk-native doesn't load DOM types.
 */

/** RN / RNW-compatible checked values (excludes string "true"/"false"). */
export type AriaChecked = boolean | 'mixed';

export interface AccessibilityStateCompat {
  readonly disabled?: boolean | undefined;
  readonly selected?: boolean | undefined;
  readonly checked?: boolean | 'mixed' | undefined;
  readonly busy?: boolean | undefined;
  readonly expanded?: boolean | undefined;
}

export interface AccessibilityValueCompat {
  readonly min?: number | undefined;
  readonly max?: number | undefined;
  readonly now?: number | undefined;
  readonly text?: string | undefined;
}

export interface A11yStateProps {
  readonly accessibilityState: AccessibilityStateCompat;
  readonly 'aria-checked'?: AriaChecked;
  readonly 'aria-disabled'?: boolean;
  readonly 'aria-selected'?: boolean;
  readonly 'aria-busy'?: boolean;
  readonly 'aria-expanded'?: boolean;
}

export interface A11yValueProps {
  readonly accessibilityValue: AccessibilityValueCompat;
  readonly accessibilityValueMin?: number;
  readonly accessibilityValueMax?: number;
  readonly accessibilityValueNow?: number;
  readonly accessibilityValueText?: string;
  readonly 'aria-valuemin'?: number;
  readonly 'aria-valuemax'?: number;
  readonly 'aria-valuenow'?: number;
  readonly 'aria-valuetext'?: string;
}

/**
 * RN typings omit attrs RNW and native a11y still read at runtime
 * (`data-*`, `aria-*`, `accessibilityLevel`). react-native-web drops raw
 * `data-*` props and writes its `dataSet` prop as `data-*` attributes
 * instead, so `data-*` keys move there (camel-cased, as RNW expects),
 * after the entries of `own`'s `dataSet`: the caller's props spread before
 * these, whose `dataSet` this one would otherwise replace.
 */
export function rnwAttrs(
  attrs: Record<string, string | number | boolean | undefined>,
  own?: object,
): object {
  const props: Record<string, unknown> = {};
  const dataSet: Record<string, unknown> = { ...(own as { dataSet?: object } | undefined)?.dataSet };
  for (const [key, value] of Object.entries(attrs)) {
    if (!key.startsWith('data-')) props[key] = value;
    else if (value !== undefined) {
      dataSet[key.slice(5).replace(/-([a-z])/g, (_, letter: string) => letter.toUpperCase())] =
        value;
    }
  }
  if (Object.keys(dataSet).length > 0) props.dataSet = dataSet;
  return props;
}

/**
 * A key pressed on a focused element: react-native-web's `onKeyDown`, which
 * React Native's View types lack before 0.84.
 */
export interface WebKeyDownEvent {
  readonly nativeEvent: { readonly key: string; readonly shiftKey?: boolean };
  preventDefault(): void;
}

/**
 * `handler` as react-native-web's `onKeyDown` prop, typed here once so the
 * components that take keys don't each cast it.
 */
export function webKeyHandler(handler: (event: WebKeyDownEvent) => void): {
  readonly onKeyDown: (event: WebKeyDownEvent) => void;
} {
  return { onKeyDown: handler };
}

/**
 * react-native-web's `onMouseDown`, keeping focus where a press put it: the
 * mousedown's default would move focus to the nearest focusable ancestor of a
 * part that takes no pointer (a slider's thumb, focused as the press began).
 */
export const webKeepFocusOnPress: {
  readonly onMouseDown: (event: { preventDefault(): void }) => void;
} = { onMouseDown: (event) => event.preventDefault() };

export function a11yState(
  state: AccessibilityStateCompat,
): A11yStateProps {
  return {
    accessibilityState: state,
    ...(state.checked !== undefined ? { 'aria-checked': state.checked } : {}),
    ...(state.disabled !== undefined
      ? { 'aria-disabled': state.disabled }
      : {}),
    ...(state.selected !== undefined
      ? { 'aria-selected': state.selected }
      : {}),
    ...(state.busy !== undefined ? { 'aria-busy': state.busy } : {}),
    ...(state.expanded !== undefined
      ? { 'aria-expanded': state.expanded }
      : {}),
  };
}

export function a11yValue(value: AccessibilityValueCompat): A11yValueProps {
  return {
    accessibilityValue: value,
    ...(value.min !== undefined
      ? { accessibilityValueMin: value.min, 'aria-valuemin': value.min }
      : {}),
    ...(value.max !== undefined
      ? { accessibilityValueMax: value.max, 'aria-valuemax': value.max }
      : {}),
    ...(value.now !== undefined
      ? { accessibilityValueNow: value.now, 'aria-valuenow': value.now }
      : {}),
    ...(value.text !== undefined
      ? { accessibilityValueText: value.text, 'aria-valuetext': value.text }
      : {}),
  };
}

/** A DOM node as react-native-web hands it over (a View's ref is one). */
export interface WebNode {
  contains(other: WebNode): boolean;
}

/** react-native-web's blur and focus `nativeEvent`: where focus went, or came from. */
export interface WebFocusEvent {
  readonly relatedTarget: WebNode | null;
}

/** The page's `document`, on the web: just what listening on it takes. */
export interface WebDocument {
  addEventListener(
    type: string,
    listener: () => void,
    options: { readonly capture: boolean; readonly once?: boolean },
  ): void;
  removeEventListener(type: string, listener: () => void, options: { readonly capture: boolean }): void;
}

/** The page's `document` on the web, or nothing on native. */
export const webDocument = (): WebDocument | undefined =>
  (globalThis as { document?: WebDocument }).document;

/** The DOM element react-native-web focuses. */
export interface FocusTarget {
  matches?: (selector: string) => boolean;
  ownerDocument?: {
    addEventListener(type: string, listener: () => void, capture: boolean): void;
    removeEventListener(type: string, listener: () => void, capture: boolean): void;
  };
}

/**
 * The browser decides whether focus should show (`:focus-visible`), so a click
 * doesn't ring a button but Tab does.
 */
export function matchesFocusVisible(target: FocusTarget): boolean {
  try {
    return target.matches?.(':focus-visible') ?? true;
  } catch {
    // A browser too old for :focus-visible: show every focus.
    return true;
  }
}
