/**
 * What every silk drag along one axis shares: when it starts, and the speed
 * it lets go at. The numbers are `conventions.ts`'s; this is their use.
 */
import { useMemo } from 'react';
import type { PanGestureConfig } from 'react-native-gesture-handler';
import { useSharedValue } from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { swallowDragClick, WEB } from '../web/host.js';
import { gestureConventions, releaseVelocity } from './conventions.js';

const SLOP: [number, number] = [-gestureConventions.touchSlop, gestureConventions.touchSlop];

/** What `panAlong` sets itself. */
type AxisKeys = 'activeOffsetX' | 'activeOffsetY' | 'failOffsetX' | 'failOffsetY' | 'maxPointers';

/**
 * `config` as a one-finger pan along one axis: it starts once the finger moves
 * a touch slop along it, and fails on one across, so a scroll view across it
 * keeps a scroll that starts on it. On the web, a mouse drag that began on a
 * pressable doesn't also press it. Its callbacks say 'worklet' themselves.
 *
 * It merges here, not by a spread at the call: the worklets Babel plugin reads
 * an object written for a gesture hook, and throws on a spread in it.
 */
export function panAlong(
  vertical: boolean,
  config: Omit<PanGestureConfig, AxisKeys>,
): PanGestureConfig {
  const { onDeactivate } = config;
  const guarded: Omit<PanGestureConfig, AxisKeys> = {
    ...config,
    onDeactivate: (event) => {
      'worklet';
      if (WEB) scheduleOnRN(swallowDragClick);
      onDeactivate?.(event);
    },
  };
  return vertical
    ? { ...guarded, activeOffsetY: SLOP, failOffsetX: SLOP, maxPointers: 1 }
    : { ...guarded, activeOffsetX: SLOP, failOffsetY: SLOP, maxPointers: 1 };
}

/**
 * On the web, the browser's own panning a `panAlong` drag leaves to it: across
 * its axis, as a `GestureDetector`'s `touchAction`.
 */
export function crossPanning(vertical: boolean): 'pan-x' | 'pan-y' {
  return vertical ? 'pan-x' : 'pan-y';
}

export interface ReleaseTimer {
  /** The drag started or moved (call from its worklets). */
  readonly moved: () => void;
  /** The speed it lets go at: none if canceled, or if the finger had stopped (`releaseVelocity`). */
  readonly speed: (canceled: boolean, velocity: number) => number;
}

/** Times a drag's moves on the UI thread, for the speed it lets go at. */
export function useReleaseTimer(): ReleaseTimer {
  const lastMoveAt = useSharedValue(0);
  return useMemo(
    () => ({
      moved: () => {
        'worklet';
        lastMoveAt.set(Date.now());
      },
      speed: (canceled, velocity) => {
        'worklet';
        return canceled ? 0 : releaseVelocity(velocity, Date.now() - lastMoveAt.get());
      },
    }),
    [lastMoveAt],
  );
}
