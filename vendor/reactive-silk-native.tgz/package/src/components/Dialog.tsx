import { dialogRecipe, type DialogVariantProps } from '@reactive/silk-core';
import {
  type ComponentRef,
  createContext,
  type JSX,
  type ReactNode,
  type Ref,
  useContext,
  useId,
  useLayoutEffect,
  useMemo,
  useState,
} from 'react';
import {
  Modal,
  type StyleProp,
  StyleSheet,
  View,
  type ViewProps,
  type ViewStyle,
} from 'react-native';
import { rnwAttrs } from '../styles/a11yProps.js';
import { mapDialogStyle } from '../styles/mappers/overlay.js';
import { useReducedMotion } from '../styles/useReducedMotion.js';
import { useComponentDefaults } from '../theme/SilkProvider.js';
import { useTheme } from '../theme/ThemeProvider.js';
import { Heading, type HeadingProps } from './Heading.js';

interface DialogContextValue {
  readonly open: boolean;
  readonly onOpenChange: (open: boolean) => void;
  readonly titleId: string;
  /** Whether a `Dialog.Title` is rendered, so the dialog may point to it for its name. */
  readonly titled: boolean;
  readonly setTitled: (titled: boolean) => void;
}

const DialogContext = createContext<DialogContextValue | null>(null);

function useDialogContext(part: string): DialogContextValue {
  const dialog = useContext(DialogContext);
  if (!dialog) throw new Error(`Dialog.${part} must be used within Dialog.Root`);
  return dialog;
}

export interface DialogRootProps {
  /** Whether it shows. Controlled: the dialog asks to close through `onOpenChange(false)`. */
  readonly open: boolean;
  /**
   * Called with `false` for a press on the veil, Escape (web), or the back
   * button (Android).
   */
  readonly onOpenChange: (open: boolean) => void;
  readonly children?: ReactNode;
}

function DialogRoot({ open, onOpenChange, children }: DialogRootProps): JSX.Element {
  const titleId = useId();
  const [titled, setTitled] = useState(false);
  const value = useMemo<DialogContextValue>(
    () => ({ open, onOpenChange, titleId, titled, setTitled }),
    [open, onOpenChange, titleId, titled],
  );
  return <DialogContext.Provider value={value}>{children}</DialogContext.Provider>;
}

export interface DialogContentProps
  extends DialogVariantProps, Omit<ViewProps, 'children' | 'style'> {
  readonly ref?: Ref<ComponentRef<typeof View>>;
  readonly children?: ReactNode;
  /** The panel's style, after Silk's. */
  readonly style?: StyleProp<ViewStyle>;
  /** The veil's style, after Silk's (`semantic.color.overlay`). */
  readonly overlayStyle?: StyleProp<ViewStyle>;
}

/**
 * The dialog's panel over a veiled screen, on React Native's Modal (which
 * react-native-web renders as an `aria-modal` dialog that traps focus, hands
 * it back on close, and closes on Escape). Centered, or risen from the bottom
 * edge as a sheet (`placement="bottom"`). Its children lay out in the panel;
 * wrap long content in a ScrollView.
 */
function DialogContent({
  size,
  placement,
  style,
  overlayStyle,
  children,
  ref,
  ...rest
}: DialogContentProps): JSX.Element {
  const { open, onOpenChange, titleId, titled } = useDialogContext('Content');
  const { theme, density } = useTheme();
  const defaults = useComponentDefaults('Dialog');
  const reducedMotion = useReducedMotion();
  const { veil, panel } = mapDialogStyle(
    theme,
    {
      size: size ?? defaults.size ?? dialogRecipe.defaults.size,
      placement: placement ?? defaults.placement ?? dialogRecipe.defaults.placement,
    },
    density,
  );
  const close = () => onOpenChange(false);
  return (
    <Modal
      visible={open}
      transparent
      statusBarTranslucent
      animationType={reducedMotion ? 'none' : 'fade'}
      onRequestClose={close}
      {...rnwAttrs({ 'aria-labelledby': titled ? titleId : undefined })}
    >
      <View style={[veil, overlayStyle]}>
        {/*
         * A press on the veil closes it. Not a button: react-native-web's focus
         * trap focuses the first focusable element, which must be the panel's.
         */}
        <View
          style={StyleSheet.absoluteFill}
          onStartShouldSetResponder={() => true}
          onResponderRelease={close}
        />
        <View ref={ref} {...rest} style={[panel, styles.overVeil, style]}>
          {children}
        </View>
      </View>
    </Modal>
  );
}

export type DialogTitleProps = HeadingProps;

/** The dialog's name: a heading (level 2, size `md` unless given), and what screen readers announce for it. */
function DialogTitle({ level = '2', size = 'md', ...props }: DialogTitleProps): JSX.Element {
  const { titleId, setTitled } = useDialogContext('Title');
  useLayoutEffect(() => {
    setTitled(true);
    return () => setTitled(false);
  }, [setTitled]);
  return <Heading level={level} size={size} nativeID={titleId} {...props} />;
}

const styles = StyleSheet.create({
  // The veil's press catcher is positioned, so it would cover the panel otherwise.
  overVeil: { zIndex: 1 },
});

export interface DialogNamespace {
  readonly Root: typeof DialogRoot;
  readonly Content: typeof DialogContent;
  readonly Title: typeof DialogTitle;
}

export const Dialog: DialogNamespace = {
  Root: DialogRoot,
  Content: DialogContent,
  Title: DialogTitle,
};
