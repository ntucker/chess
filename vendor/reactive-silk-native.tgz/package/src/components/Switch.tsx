import { switchRecipe, type SwitchVariantProps } from '@reactive/silk-core';
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type JSX,
} from 'react';
import {
  Animated,
  I18nManager,
  View,
  type LayoutChangeEvent,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { a11yState, rnwAttrs } from '../styles/a11yProps.js';
import {
  minTouchHitSlop,
  switchThumbInset,
  switchThumbTravel,
} from '../styles/controlGeometry.js';
import { mapSwitchStyle } from '../styles/mappers/controls.js';
import { useReducedMotion } from '../styles/useReducedMotion.js';
import { useComponentDefaults } from '../theme/SilkProvider.js';
import { useTheme } from '../theme/ThemeProvider.js';
import { Pressable, type PressableProps } from './Pressable.js';
import {
  useFieldControlProps,
  useFieldControlRegistration,
} from './Field.js';
import { useControllableValue } from './useControllableValue.js';

export interface SwitchProps
  extends SwitchVariantProps,
    Omit<PressableProps, 'children' | 'style' | 'onPress' | 'focusRing'> {
  readonly style?: StyleProp<ViewStyle>;
  readonly checked?: boolean;
  readonly defaultChecked?: boolean;
  readonly onCheckedChange?: (checked: boolean) => void;
  readonly disabled?: boolean;
  readonly invalid?: boolean;
  readonly required?: boolean;
  readonly 'aria-describedby'?: string;
}

export function Switch({
  size,
  tone,
  checked: checkedProp,
  defaultChecked = false,
  onCheckedChange,
  disabled,
  invalid,
  required,
  style,
  ref,
  onLayout: onLayoutProp,
  nativeID,
  accessibilityLabel,
  accessibilityHint,
  accessibilityLabelledBy,
  accessibilityState,
  'aria-describedby': ariaDescribedBy,
  ...rest
}: SwitchProps): JSX.Element {
  const { theme, density } = useTheme();
  const defaults = useComponentDefaults('Switch');
  const resolved: SwitchVariantProps = {
    size: size ?? defaults.size ?? switchRecipe.defaults.size,
    tone: tone ?? defaults.tone ?? switchRecipe.defaults.tone,
  };
  const fieldProps = useFieldControlProps({
    disabled,
    required,
    'aria-invalid': invalid,
    nativeID,
    accessibilityLabel,
    accessibilityHint,
    accessibilityLabelledBy,
    'aria-describedby': ariaDescribedBy,
  });
  const isDisabled = Boolean(fieldProps.disabled);
  const isInvalid = Boolean(fieldProps.invalid);
  const [checked, setUncontrolled] = useControllableValue(
    checkedProp,
    defaultChecked,
  );

  const { track, thumb, travel: defaultTravel } = mapSwitchStyle(
    theme,
    resolved,
    density,
    {
      checked,
      invalid: isInvalid,
      disabled: isDisabled,
    },
  );
  const thumbSize = thumb.width;
  const [layoutWidth, setLayoutWidth] = useState(0);
  const travel =
    layoutWidth > 0
      ? switchThumbTravel(layoutWidth, thumbSize)
      : defaultTravel;
  const reduced = useReducedMotion();
  const rtl = I18nManager.isRTL;
  const signedTravel = (rtl ? -1 : 1) * travel;

  const onLayout = (event: LayoutChangeEvent): void => {
    setLayoutWidth(event.nativeEvent.layout.width);
    onLayoutProp?.(event);
  };
  const offset = useRef(new Animated.Value(checked ? signedTravel : 0)).current;

  useEffect(() => {
    const toValue = checked ? signedTravel : 0;
    if (reduced) {
      offset.setValue(toValue);
      return;
    }
    const animation = Animated.timing(offset, {
      toValue,
      duration: theme.semantic.motion.fast.durationMs,
      useNativeDriver: true,
    });
    animation.start();
    return () => {
      animation.stop();
    };
  }, [
    checked,
    signedTravel,
    reduced,
    offset,
    theme.semantic.motion.fast.durationMs,
  ]);

  const hitSlop = minTouchHitSlop(track.height);
  const stateProps = a11yState({
    ...accessibilityState,
    checked: Boolean(checked),
    disabled: isDisabled,
  });

  const toggle = useCallback((): void => {
    if (isDisabled) return;
    const next = !checked;
    setUncontrolled(next);
    onCheckedChange?.(next);
  }, [checked, isDisabled, onCheckedChange, setUncontrolled]);
  useFieldControlRegistration(toggle);

  return (
    <Pressable
      ref={ref}
      {...rest}
      {...stateProps}
      accessibilityRole="switch"
      accessibilityLabel={fieldProps.accessibilityLabel}
      accessibilityHint={fieldProps.accessibilityHint}
      accessibilityLabelledBy={fieldProps.accessibilityLabelledBy}
      nativeID={fieldProps.nativeID}
      disabled={isDisabled}
      hitSlop={hitSlop}
      focusRing={isInvalid ? 'danger' : resolved.tone}
      onPress={toggle}
      onLayout={onLayout}
      style={({ focusVisible }) => [
        // The ring replaces the invalid outline while focused.
        focusVisible && isInvalid
          ? mapSwitchStyle(theme, resolved, density, {
              checked,
              invalid: true,
              disabled: isDisabled,
              focusVisible,
            }).track
          : track,
        style,
      ]}
      {...rnwAttrs({
        'aria-describedby': fieldProps['aria-describedby'],
        'aria-invalid': fieldProps['aria-invalid'],
        'aria-required': fieldProps['aria-required'],
        'data-invalid': isInvalid ? 'true' : undefined,
        'data-state': checked ? 'checked' : 'unchecked',
      })}
    >
      <Animated.View
        style={[
          thumb,
          {
            marginStart: switchThumbInset,
            transform: [{ translateX: offset }],
          },
        ]}
      />
    </Pressable>
  );
}
